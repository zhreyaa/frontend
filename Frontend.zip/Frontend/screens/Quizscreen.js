import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

export default function Quizscreen() {
  return (
    <View>
      <Text>Quizscreen</Text>
    </View>
  )
}

const styles = StyleSheet.create({})