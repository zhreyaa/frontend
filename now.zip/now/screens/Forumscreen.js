import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

export default function Forumscreen (){
  return (
    <View>
      <Text>Forumscreen</Text>
    </View>
  )
}

// export default Forumscreen

const styles = StyleSheet.create({})