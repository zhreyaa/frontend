import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

export default function Homescreen() {
  return (
    <View>
      <Text>Homescreen</Text>
    </View>
  )
}

// export default Homescreen

const styles = StyleSheet.create({})