import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

export default function  Createscreen () {
  return (
    <View>
      <Text>Createscreen</Text>
    </View>
  )
}

// export default Createscreen

const styles = StyleSheet.create({})