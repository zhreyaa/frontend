import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  // faCommentDots,
  faBars,
  faXmark,
} from "@fortawesome/free-solid-svg-icons";
import "../Styles/Navbar2.css";
import { Link } from "react-router-dom";
// import { toast } from "react-toastify";

function Navbar2() {
  const [nav, setNav] = useState(false);
  // const [isButtonDisabled, setIsButtonDisabled] = useState(false);

  const openNav = () => {
    setNav(!nav);
  };

  // const handleChatBtnClick = () => {
  //   if (!isButtonDisabled) {
  //     toast.info("Experiencing high traffic, Please wait a moment.", {
  //       position: toast.POSITION.TOP_CENTER,
  //       onOpen: () => setIsButtonDisabled(true),
  //       onClose: () => setIsButtonDisabled(false),
  //     });
  //   }
  // };

  return (
    <div className="navbar-section">
      <h1 className="navbar-title">
        <Link to="/Healofy">
          Healofy 
        </Link>
      </h1>

      {/* Desktop */}
      <ul className="navbar-items">
        <li>
          <Link to="/Healofy" className="navbar-links">
            Home
          </Link>
        </li>
        <li>
          <a href="#blogs" className="navbar-links">
            Blogs
          </a>
        </li>
        <li>
          <a href="#posts" className="navbar-links">
            Posts
          </a>
        </li>
        <li>
          <a href="#podcasts" className="navbar-links">
            Podcasts
          </a>
        </li>
        <li>
          <a href="#forum" className="navbar-links">
            Forum
          </a>
        </li>
      </ul>

      <Link to={'/signup'}><button
        className="navbar-btn"> Sign up
      </button></Link>
      
      {/* Mobile */}
      <div className={`mobile-navbar ${nav ? "open-nav" : ""}`}>
        <div onClick={openNav} className="mobile-navbar-close">
          <FontAwesomeIcon icon={faXmark} className="hamb-icon" />
        </div>

        <ul className="mobile-navbar-links">
          <li>
            <Link onClick={openNav} to="/">
              Home
            </Link>
          </li>
          <li>
            <a onClick={openNav} href="#blogs">
              Blogs
            </a>
          </li>
          <li>
            <a onClick={openNav} href="#Posts">
              Posts
            </a>
          </li>
          <li>
            <a onClick={openNav} href="#podcasts">
              Podcasts
            </a>
          </li>
          <li>
            <a onClick={openNav} href="#forum">
              Forum
            </a>
          </li>
          <li>
            <a onClick={openNav} href="#contact">
              Contact
            </a>
          </li>
        </ul>
      </div>

      {/* Hamburger Icon */}
      <div className="mobile-nav">
        <FontAwesomeIcon
          icon={faBars}
          onClick={openNav}
          className="hamb-icon"
        />
      </div>
    </div>
  );
}

export default Navbar2;
