import React from 'react';
import '../Styles/Adlogin.css';
import { Link } from 'react-router-dom';

export const Adlogin = () => {
    return (
        <div className="login">
            <div className="login-container">
                <h1>Admin Sign In</h1>
                <div className="login-fields">
                    <input type="email" placeholder='Email Address' />
                    <input type="password" placeholder='Password' />
                </div>
                <button>Sign In</button>  
                <Link to={'/Healofy'}><button>Back to Home</button></Link>
            </div>
        </div>
    );
}

export default Adlogin;
