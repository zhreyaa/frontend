import React from 'react'
import '../Styles/Loginsignup.css'
import { Link } from 'react-router-dom'
export const Loginsignup = () => {
    return (
      <>
    <div className="login">
     <div className="login-container">
        <h1>Sign Up</h1>
        <div className="login-fields">
            <input type="text" placeholder='Your Name' />
            <input type="email" placeholder='Email Address' />
            <input type="password" placeholder='Password' />
            </div>
          <button>Continue</button>
          <p className="login-login">Already have an account? <Link to='/signin'><span>Login here</span></Link></p>  
          <div className="login-agree">
            <input type="checkbox" name="" id="" />
            <p>By continuing, I agree to the terms of use & privacy policy.</p>
            
          </div>
          <div className='doctor'>
               <p className='doctor-signin'>Signup as Doctor? <Link to='/docsignup'><span>Signup here</span></Link></p>
          </div>
          <Link to={'/Healofy'}><button>Back to Home</button></Link>
     </div>
    </div>
 </>
    )
}

export default Loginsignup