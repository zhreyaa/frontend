import React, { useState } from "react";
import { customerReviews } from "../Scripts/reviews";
import "../Styles/Main.css";
import InformationCard from "../Components/InformationCard";
import { Link } from "react-router-dom";
import Navbar2 from "../Components/Navbar";

function Main() {
  let rMessage, rName, rLocation;
  const reviewsLength = customerReviews.length - 1;
  const [review, setReview] = useState(0);

  // back to previous review
  const backBtnClick = () => {
    setReview(review <= 0 ? reviewsLength : review - 1);
    handleReviewsUpdation();
  };

  // go to newer review
  const frontBtnClick = () => {
    setReview(review >= reviewsLength ? 0 : review + 1);
    handleReviewsUpdation();
  };

  // update reviews
  const handleReviewsUpdation = () => {
    const reviewMessage = customerReviews[review];
    rName = reviewMessage.name;
    rLocation = reviewMessage.location;
    rMessage = reviewMessage.message;
  };

  // list review on visit
  handleReviewsUpdation();

  return (
    <div>
        <Navbar2></Navbar2>
    <div className="review-section" id="reviews">
      <div className="rw-text-content">
        <p className="rw-text-title">
          <span className="rw-text-num">Customer Reviews</span>
        </p>

        {/* <p className="rw-text-desc">Don't believe us, Check clients word</p> */}

        <p className="rw-text-format">
          <span className="rw-text-quote1">''</span>
          <span className="rw-review">{rMessage}</span>
          <span className="rw-text-quote2">''</span>
        </p>

        <div className="rw-authors">
          <div className="rw-names">
            <p className="rw-reviewer-name">{rName}</p>
            <p className="rw-reviewer-place">{rLocation}</p>
          </div>

          <div className="rw-btns">
            <button
              className="rw-next-btn"
              type="button"
              onClick={backBtnClick}
            >
              ←
            </button>
            <button
              className="rw-next-btn"
              type="button"
              onClick={frontBtnClick}
            >
              →
            </button>
          </div>
        </div>
      </div>
      
    </div>
    <div className="info-section" id="services">
      <div className="info-title-content">
        <h3 className="info-title">
          <span>What We Do</span>
        </h3>
        <p className="info-description">
          We bring self help to your convenience, offering a comprehensive
          range of on-demand self care services tailored to your needs. Our
          platform allows you to connect with experienced online doctors who
          provide expert medical advice, or you can use the app to just feel better.
        </p>
      </div>
      <div className="info-cards-content">
        <InformationCard
          title="Emergency Care"
          description="Our Emergency Care service is designed to be your reliable support
            in critical situations. Whether it's a sudden medical concern that requires immediate attention, our team of
            dedicated self help professionals is available 24/7 to provide
            prompt and efficient care."
     
        />

       <InformationCard
          title="Chat with experts"
          description="We value the time and well-being of our patients and want them to only spend their tiem correctly
          and thus they can chat with the expert psychiatricts that are available with us at Healofy!"
      
        />

       <Link to={'/home'}> <InformationCard
          title="Enjoy the positive community"
          description="The healofy community is a positive platform where we engage the users with jokes, blogs, posts, forum of 
          question and answers so that they can get better by interacting with all of them."
     
        /> </Link>
      </div>
    </div>
    </div>

    
  );
}

export default Main;
