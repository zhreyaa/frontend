import React, { useState, useEffect } from 'react';
import { ScrollView, View, Text, Image, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import axios from 'axios';
import { FontAwesome } from "@expo/vector-icons";

export default function Forumscreen({ navigation }) {
  const [posts, setPosts] = useState([]);
  const [title, postTitle] = useState("");
  const [content, setContent] = useState("");
  const [description, postDescription] = useState("");

  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = () => {
    const loginUrl = "http://localhost:9090/api/posts/allPosts";
    const method='GET';
    const data={
       title:"RECOGNIZING THE SIGNS OF BIPOLAR DISORDER" 
    }

    axios({
        url: loginUrl,
        method: method,
        headers: {
           
        },
        data: data,
    })
        .then((res) => {console.log("Get done"+ res.data);
        setPosts(res.data.content)
        // navigation.navigate('Forumscreen')})
        })
        .catch((err) => {console.log("Some error occured")});
  };

  const addComment = (postId) => {
    const commentUrl = `http://localhost:9090/api/posts/${postId}/createComment`;
    
    axios.post(commentUrl, { body: content })
      .then((res) => {
        console.log("Comment added:", res.data);
        // Refresh posts after adding comment
        fetchPosts();
        // Clear comment input
        setContent("");
      })
      .catch((err) => {
        console.log("Error adding comment:", err);
      });
  };

  const deleteComment = (postId, commentId) => {
    const deleteUrl = `http://localhost:9090/api/posts/${postId}/comments/${commentId}`;
    
    axios.delete(deleteUrl)
      .then((res) => {
        console.log("Comment deleted:", res.data);
        // Refresh posts after deleting comment
        fetchPosts();
      })
      .catch((err) => {
        console.log("Error deleting comment:", err);
      });
  };

  return (
    <ScrollView style={{backgroundColor:"white"}}>
      <View style={{ alignItems: "center", marginTop: 30 }}>
       <Image
         style={{ width: 100, height: 60, resizeMode: "contain" }}
           source={require('./../assets/healofy.png')}
        />
       </View> 

      <View style={styles.container}>
        {posts.map(post => (
          <View key={post.id} style={styles.postContainer}>
            <Text style={styles.postTitle}>{post.title}</Text>
            <Text style={styles.postContent}>{post.content}</Text>
            <Text style={styles.postDescription}>{post.description}</Text>
            {/* Additional post details can be displayed here */}

{/* Add comment input */}
<View
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 10,
                marginTop: 15,
              }}
            >
              <FontAwesome name="comment-o" size={18} color="#124b46" />
            </View>
<View style={{ flexDirection: "row", marginTop: 10 }}>
              <TextInput
                value={content}
                onChangeText={(text) => setContent(text)}
                placeholderTextColor={"black"}
                placeholder="Add Comment"
                multiline
                style={{ flex: 1, borderWidth: 1, borderColor: "#ccc", borderRadius: 5, paddingHorizontal: 10 }}
              />
              <TouchableOpacity
                onPress={() => addComment(post.id)}
                style={{ backgroundColor: "#124b46", paddingHorizontal: 10, justifyContent: "center", alignItems: "center", marginLeft: 10, borderRadius: 5 }}
              >
                <Text style={{ color: "white", fontWeight: "bold" }}>Add</Text>
              </TouchableOpacity>
            </View>

            {/* Render comments */}
            {post.comments.map(comment => (
              <View key={comment.id} style={{ flexDirection: "row", alignItems: "center", marginTop: 10 }}>
                <Text style={{ flex: 1 }}>{comment.body}</Text>
                <TouchableOpacity onPress={() => deleteComment(post.id, comment.id)}>
                  <FontAwesome name="trash" size={18} color="#FF0000" />
                </TouchableOpacity>
              </View>
            ))}

          </View>
        ))}
      <TouchableOpacity
        style={styles.fab}
        onPress={() => navigation.navigate("Createscreen")}
      >
        <FontAwesome name="plus" size={24} color="#124b46" />
      </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    padding: 20,
  },
  postContainer: {
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
  },
  postTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  postContent: {
    fontSize: 16,
    marginBottom: 10,
  },
  addButton: {
    backgroundColor: '#124b46',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    alignItems: 'center',
    marginTop: 20,
  },
  addButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  fab: {
          position: "absolute",
          width: 60,
          height: 60,
          alignItems: "center",
          justifyContent: "center",
          right: 20,
          bottom: 20,
          backgroundColor: "#88a5a2",
          borderRadius: 30,
          elevation: 8,
        },
});
