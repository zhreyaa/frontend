import React, { useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { Octicons, Ionicons } from '@expo/vector-icons';
import { Formik } from 'formik';
import axios from 'axios';
import {
    StyledContainer,
    InnerContainer,
    PageLogo,
    PageTitle,
    StyledFormArea,
    SubTitle,
    RightIcon,
    LeftIcon,
    ButtonText,
    StyledButton,
    StyledInputLabel,
    StyledTextInput,
    Colors,
    Msgbox,
    Line,
    ExtraText,
    ExtraView,
    TextLink,
    TextLinkContent
} from './../components/styles';
import KeyboardAvoidWrap from '../components/KeyboardAvoidWrap';
import { View, TouchableOpacity, Text, ScrollView } from 'react-native';

const { brand, darkLight, primary } = Colors;

const Appointment = ({ navigation }) => {
    const [hidePassword, setHidePassword] = useState(true);
    const [selectedDoctor, setSelectedDoctor] = useState('');
    const [selectedTiming, setSelectedTiming] = useState('');

    const [email, setEmail] = useState('');
    const [firstName, setfirstName] = useState('');
    const [lastName, setlastName] = useState('');
    const [severity, setSeverity] = useState('');
    const [age, setAge] = useState('');

    const bookAppointment=()=>{
        const loginUrl = "http://localhost:9090/api/createAppointment";
        const method='POST';
        const data={
            firstName:firstName,
            lastName:lastName,
            email:email,
            severity:severity,
            age:age,

        }

        axios({
            url: loginUrl,
            method: method,
            headers: {
                
            },
            data: data,
        })
            .then((res) => {console.log("Appointment booked");
            navigation.navigate('Home')})
            .catch((err) => {console.log("Some error occured")});
    }


    // Define your available time slots
    const timeSlots = [
        '9:00 AM',
        '10:00 AM',
        '11:00 AM',
        '12:00 PM',
        '1:00 PM',
        '2:00 PM',
        '3:00 PM',
        '4:00 PM',
        '5:00 PM',
        '6:00 PM',
        '7:00 PM',
        '8:00 PM',
        'Any time is fine'
    ];

    // Define your available doctors
    const doctors = ['Dr. Smith', 'Dr. Johnson', 'Dr. Brown', 'Dr. Davis'];

    return (
        // <KeyboardAvoidWrap>
        <ScrollView>
            <StyledContainer>
                <StatusBar style='dark' />
                <InnerContainer>
                    <PageTitle>Appointment</PageTitle>
                    <SubTitle style={{marginLeft:10,marginRight:10,alignSelf:"center"}}>Book an appointment with a doctor</SubTitle>

                    <Formik
                        initialValues={{ name: '', email: '', age: '' }}
                        onSubmit={(values) => {
                            console.log(values);
                            // Perform appointment booking logic here
                        }}
                    >
                        {({ handleChange, handleBlur, values }) => (
                            <StyledFormArea>
                                <MyTextInput
                                    label="firstName"
                                    icon="person"
                                    placeholder="John Doe"
                                    placeholderTextColor={darkLight}
                                    onChangeText={(text)=> setfirstName(text)}
                                    onBlur={handleBlur('firstName')}
                                    values={values.name}
                                />

<MyTextInput
                                    label="lastName"
                                    icon="person"
                                    placeholder="John Doe"
                                    placeholderTextColor={darkLight}
                                    onChangeText={(text)=> setlastName(text)}
                                    onBlur={handleBlur('lastName')}
                                    values={values.name}
                                />

                                <MyTextInput
                                    label="Email Address"
                                    icon="mail"
                                    placeholder="john@example.com"
                                    placeholderTextColor={darkLight}
                                    onChangeText={(text)=> setEmail(text)}
                                    onBlur={handleBlur('email')}
                                    values={values.email}
                                    keyboardType="email-address"
                                />

                                <MyTextInput
                                    label="Age"
                                    icon="calendar"
                                    placeholder="Enter your age"
                                    placeholderTextColor={darkLight}
                                    onChangeText={(text)=> setAge(text)}
                                    onBlur={handleBlur('age')}
                                    values={values.age}
                                    keyboardType="numeric"
                                />

<MyTextInput
                                    label="Severity"
                                    placeholder="Depression"
                                    placeholderTextColor={darkLight}
                                    onChangeText={(text)=> setSeverity(text)}
                                    onBlur={handleBlur('severity')}
                                    values={values.severity}
                                />

                                {/* Select Doctor Dropdown */}
                                <View style={{ marginBottom: 20 }}>
                                    <StyledInputLabel>Select Doctor</StyledInputLabel>
                                    {doctors.map((doctor, index) => (
                                    <TouchableOpacity
                                        key={index}
                                        style={{
                                            paddingHorizontal: 15,
                                            paddingVertical: 10,
                                            marginBottom: 10,
                                            backgroundColor: selectedDoctor === doctor ? primary : 'transparent',
                                            borderRadius: 5,
                                        }}
                                        onPress={() => setSelectedDoctor({doctor})}
                                    >
                                         <Text style={{ color: selectedDoctor === doctor ? darkLight :'#124b46' }}>{doctor}</Text>
                                    </TouchableOpacity>
                                     ))}
                                </View>

                                {/* Time Slots */}
                                <View style={{ marginBottom: 20 }}>
                                    <StyledInputLabel>Select Preferred Timing</StyledInputLabel>
                                    {timeSlots.map((time, index) => (
                                        <TouchableOpacity
                                            key={index}
                                            style={{
                                                paddingHorizontal: 15,
                                                paddingVertical: 10,
                                                marginBottom: 10,
                                                backgroundColor: selectedTiming === time ? primary : 'transparent',
                                                borderRadius: 5,
                                            }}
                                            onPress={() => setSelectedTiming(time)}
                                        >
                                            <Text style={{ color: selectedTiming === time ? darkLight : '#124b46' }}>{time}</Text>
                                        </TouchableOpacity>
                                    ))}
                                </View>

                                <StyledButton onPress={bookAppointment}>
                                    <ButtonText>
                                        Book Appointment
                                    </ButtonText>
                                </StyledButton>

                                <Line />

                            </StyledFormArea>
                        )}
                    </Formik>
                </InnerContainer>
            </StyledContainer>
        {/* </KeyboardAvoidWrap> */}
        </ScrollView>
    );
};

const MyTextInput = ({ label, icon, isPassword, hidePassword, setHidePassword, ...props }) => {
    return (
        <View>
            <LeftIcon>
                <Octicons name={icon} size={30} color={brand} />
            </LeftIcon>
            <StyledInputLabel>{label}</StyledInputLabel>
            <StyledTextInput {...props} />
            {isPassword && (
                <RightIcon onPress={() => setHidePassword(!hidePassword)}>
                    <Ionicons name={hidePassword ? 'eye-off' : 'eye'} size={30} color={darkLight} />
                </RightIcon>
            )}
        </View>
    );
};

export default Appointment;
