import { StyleSheet, Text, View , Image} from 'react-native'
import React, { useState } from 'react'
import { ScrollView, TextInput , TouchableOpacity} from 'react-native'
import { BottomTabBar } from '@react-navigation/bottom-tabs';
import { useNavigation } from "@react-navigation/native";
import axios from "axios";

export default function Createscreen() {
    // const [content, setContent] = useState("");
    const navigation = useNavigation();
    const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [content, setContent] = useState('');

    const onSubmit = () => {
      const loginUrl = "http://localhost:9090/api/posts/createPost";
      const method='POST';
      const data={
         title:title,
         description:description,
         content:content
              }

      axios({
          url: loginUrl,
          method: method,
          headers: {
             
          },
          data: data,
      })
          .then((res) => {console.log("Create post done");
          navigation.navigate('Forumscreen')})
          .catch((err) => {console.log("Some error occured")});
  }

  return (
  
  <ScrollView>
      <View style={styles.container}>
        <Image
          style={styles.logo}
          source={require('./../assets/healofy.png')}
        />
        <TextInput
          style={styles.input}
          value={title}
          onChangeText={setTitle}
          placeholder="Title"
          placeholderTextColor="gray"
        />
        <TextInput
          style={styles.input}
          value={description}
          onChangeText={setDescription}
          placeholder="Description"
          placeholderTextColor="gray"
        />
        <TextInput
          style={styles.input}
          value={content}
          onChangeText={setContent}
          placeholder="Content"
          placeholderTextColor="gray"
          multiline
        />
        <TouchableOpacity
          style={styles.button}
          onPress={onSubmit}
        >
          <Text style={styles.buttonText}>Create Post</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    alignItems: 'center',
    padding: 20,
  },
  logo: {
    width: 60,
    height: 40,
    resizeMode: 'contain',
    marginBottom: 20,
  },
  input: {
    width: '100%',
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    marginBottom: 20,
  },
  button: {
    width: '100%',
    backgroundColor: '#124b46',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});


// import React, { useState } from 'react';
// import { ScrollView, View, Image, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
// import axios from 'axios';

// export default function CreateScreen() {
//   const [title, setTitle] = useState('');
//   const [description, setDescription] = useState('');
//   const [content, setContent] = useState('');

//   const handleCreatePost = () => {
//     const postData = {
//       title,
//       description,
//       content,
//     };

//     axios.post('http://localhost:9090/api/posts/createPost', postData)
//       .then((response) => {
//         console.log('Post created successfully:', response.data);
//         // Reset input fields after successful post creation
//         setTitle('');
//         setDescription('');
//         setContent('');
//         // Optionally, navigate to a different screen after post creation
//       })
//       .catch((error) => {
//         console.error('Error creating post:', error);
//       });
//   };

//   return (
//     <ScrollView>
//       <View style={styles.container}>
//         <TextInput
//           style={styles.input}
//           value={title}
//           onChangeText={setTitle}
//           placeholder="Title"
//           placeholderTextColor="gray"
//         />
//         <TextInput
//           style={styles.input}
//           value={description}
//           onChangeText={setDescription}
//           placeholder="Description"
//           placeholderTextColor="gray"
//         />
//         <TextInput
//           style={styles.input}
//           value={content}
//           onChangeText={setContent}
//           placeholder="Content"
//           placeholderTextColor="gray"
//           multiline
//         />
//         <TouchableOpacity
//           style={styles.button}
//           onPress={handleCreatePost}
//         >
//           <Text style={styles.buttonText}>Share Post</Text>
//         </TouchableOpacity>
//       </View>
//     </ScrollView>
//   );
// }
