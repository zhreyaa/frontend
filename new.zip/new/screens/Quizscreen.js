import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ScrollView } from 'react-native';
// import { useNavigation } from '@react-navigation/core';
export default function Quizscreen({navigation})
 {
    const [answers, setAnswers] = useState({
        q1: '',
        q2: '',
        q3: '',
        q4: '',
        q5: '',
    });

    // const navigation=useNavigation();

    const handleOptionChange = (question, option) => {
        setAnswers((prevAnswers) => ({
            ...prevAnswers,
            [question]: option,
        }));
    };

    return (
      <ScrollView>
        <View style={styles.container}>
           <Image style={{
            flexDirection: "row",
            alignSelf: "center"}} source={require("../assets/healofy.png")}/>
            {/* Question 1 */}
            <Text style={styles.question}>How are you feeling today?</Text>
            <TouchableOpacity onPress={() => handleOptionChange('q1', 'Happy')} style={styles.option}>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Ionicons name={answers.q1 === 'Happy' ? 'radio-button-on' : 'radio-button-off'} size={24} color={answers.q1 === 'Happy' ? 'blue' : 'black'} />
                    <Text style={styles.optionText}>Happy</Text>
                </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => handleOptionChange('q1', 'Sad')} style={styles.option}>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Ionicons name={answers.q1 === 'Sad' ? 'radio-button-on' : 'radio-button-off'} size={24} color={answers.q1 === 'Sad' ? 'blue' : 'black'} />
                    <Text style={styles.optionText}>Sad</Text>
                </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => handleOptionChange('q1', 'Neutral')} style={styles.option}>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Ionicons name={answers.q1 === 'Neutral' ? 'radio-button-on' : 'radio-button-off'} size={24} color={answers.q1 === 'Neutral' ? 'blue' : 'black'} />
                    <Text style={styles.optionText}>Neutral</Text>
                </View>
            </TouchableOpacity>

            {/* Question 2 */}
            <Text style={styles.question}>How would you rate your energy level?</Text>
            <TouchableOpacity onPress={() => handleOptionChange('q2', 'High')} style={styles.option}>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Ionicons name={answers.q2 === 'High' ? 'radio-button-on' : 'radio-button-off'} size={24} color={answers.q2 === 'High' ? 'blue' : 'black'} />
                    <Text style={styles.optionText}>High</Text>
                </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => handleOptionChange('q2', 'Medium')} style={styles.option}>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Ionicons name={answers.q2 === 'Medium' ? 'radio-button-on' : 'radio-button-off'} size={24} color={answers.q2 === 'Medium' ? 'blue' : 'black'} />
                    <Text style={styles.optionText}>Medium</Text>
                </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => handleOptionChange('q2', 'Low')} style={styles.option}>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Ionicons name={answers.q2 === 'Low' ? 'radio-button-on' : 'radio-button-off'} size={24} color={answers.q2 === 'Low' ? 'blue' : 'black'} />
                    <Text style={styles.optionText}>Low</Text>
                </View>
            </TouchableOpacity>

            {/* Question 3 */}
            <Text style={styles.question}>Are you experiencing any stress?</Text>
            <TouchableOpacity onPress={() => handleOptionChange('q3', 'Yes')} style={styles.option}>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Ionicons name={answers.q3 === 'Yes' ? 'radio-button-on' : 'radio-button-off'} size={24} color={answers.q3 === 'Yes' ? 'blue' : 'black'} />
                    <Text style={styles.optionText}>Yes</Text>
                </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => handleOptionChange('q3', 'No')} style={styles.option}>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Ionicons name={answers.q3 === 'No' ? 'radio-button-on' : 'radio-button-off'} size={24} color={answers.q3 === 'No' ? 'blue' : 'black'} />
                    <Text style={styles.optionText}>No</Text>
                </View>
            </TouchableOpacity>

            {/* Question 4 */}
            <Text style={styles.question}>How well are you sleeping?</Text>
            <TouchableOpacity onPress={() => handleOptionChange('q4', 'Good')} style={styles.option}>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Ionicons name={answers.q4 === 'Good' ? 'radio-button-on' : 'radio-button-off'} size={24} color={answers.q4 === 'Good' ? 'blue' : 'black'} />
                    <Text style={styles.optionText}>Good</Text>
                </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => handleOptionChange('q4', 'Poor')} style={styles.option}>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Ionicons name={answers.q4 === 'Poor' ? 'radio-button-on' : 'radio-button-off'} size={24} color={answers.q4 === 'Poor' ? 'blue' : 'black'} />
                    <Text style={styles.optionText}>Poor</Text>
                </View>
            </TouchableOpacity>

            {/* Question 5 */}
            <Text style={styles.question}>How focused are you feeling?</Text>
            <TouchableOpacity onPress={() => handleOptionChange('q5', 'Very Focused')} style={styles.option}>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Ionicons name={answers.q5 === 'Very Focused' ? 'radio-button-on' : 'radio-button-off'} size={24} color={answers.q5 === 'Very Focused' ? 'blue' : 'black'} />
                    <Text style={styles.optionText}>Very Focused</Text>
                </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => handleOptionChange('q5', 'Somewhat Focused')} style={styles.option}>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Ionicons name={answers.q5 === 'Somewhat Focused' ? 'radio-button-on' : 'radio-button-off'} size={24} color={answers.q5 === 'Somewhat Focused' ? 'blue' : 'black'} />
                    <Text style={styles.optionText}>Somewhat Focused</Text>
                </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => handleOptionChange('q5', 'Distracted')} style={styles.option}>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Ionicons name={answers.q5 === 'Distracted' ? 'radio-button-on' : 'radio-button-off'} size={24} color={answers.q5 === 'Distracted' ? 'blue' : 'black'} />
                    <Text style={styles.optionText}>Distracted</Text>
                </View>
            </TouchableOpacity>
            <View >
            <TouchableOpacity
                    style={{
                        marginTop: 30,
                        backgroundColor: "#124b46",
                        paddingVertical: 10,
                        paddingHorizontal: 20,
                        borderRadius: 5,
                        width: 180,
                        alignSelf: "center",
                    }}

                    onPress={() => navigation.goBack()}
                >
                    <Text style={{ color: "white", alignSelf: "center" }}>Submit</Text>
                </TouchableOpacity>
  </View>

        </View>
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
      backgroundColor:"white",
        flex: 1,
        padding: 20,
    },
    question: {
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 10,
        color:"#124b46"
    },
    option: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 5,
    },
    optionText: {
        marginLeft: 10,
        fontSize: 16,
    },
});

