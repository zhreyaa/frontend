import React, {useState} from 'react';
import { StatusBar } from 'expo-status-bar';
import axios from 'axios';
import {Octicons, Ionicons, Fontisto} from '@expo/vector-icons';
import {
    StyledContainer,
    InnerContainer,
    PageLogo,
    PageTitle,
    StyledFormArea,
    SubTitle,
    RightIcon,
    LeftIcon,
    ButtonText,
    StyledButton,
    StyledInputLabel,
    StyledTextInput,
    Colors,
    Msgbox,
    Line,
    ExtraText,
    ExtraView,
    TextLink,
    TextLinkContent
} from './../components/styles';

import {Formik} from 'formik';
import KeyboardAvoidWrap from '../components/KeyboardAvoidWrap';
import { ScrollView, View } from 'react-native';

const {brand, darkLight, primary} = Colors;


const Login = ({navigation}) => {
    const [hidePassword, setHidePassword] = useState(true);

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const onPressLogin = () => {
        const loginUrl = "http://localhost:9091/api/v1/auth/authenticate";
        const method='POST';
        const data={
            email:email,
            password:password
        }

        axios({
            url: loginUrl,
            method: method,
            headers: {
               
            },
            data: data,
        })
            .then((res) => {
                if(res.status === 200){console.log("Login successful");
            navigation.navigate('Home')}
            else{
                console.log("Login not successful");
            }})
            .catch((err) => {console.log("Some error occured")});
    }



  return (
    // <KeyboardAvoidWrap>
    <ScrollView style={{backgroundColor:"white"}}>
     <StyledContainer >
     <StatusBar style='dark'/>
        <InnerContainer>
             <PageLogo
                 resizeMode="cover" source={require('./../assets/healofy.png')} 
                />
             <PageTitle>HEALOFY</PageTitle>
             <SubTitle>Account Login</SubTitle>
            
             <Formik
             initialValues={{email: '', password: ""}}
             onSubmit={(values) =>{
                console.log(values);
                navigation.navigate("Home");
             }}
             >
               {({handleChange, handleBlur, values})=>(
                <StyledFormArea>
               
                <MyTextInput
                    label="Email Address"
                    icon="mail"
                    placeholder="xyz.gmail.com"
                    placeholderTextColor={darkLight}
                    onChangeText={(text)=> setEmail(text)}
                    // onBlur={handleBlur('email')}
                    values={values.email}
                    // keyboardType="email-address"
                />

                <MyTextInput
                    label="Password"
                    icon="lock"
                    placeholder="* * * * * *"
                    placeholderTextColor={darkLight}
                    onChangeText={(text)=> setPassword(text)}
                    // onBlur={handleBlur('password')}
                    values={values.password}
                    secureTextEntry={hidePassword}
                    isPassword={true}
                    hidePassword={hidePassword}
                    setHidePassword={setHidePassword}
                />

                <Msgbox>
                    ...
                </Msgbox>

                {/* <StyledButton onPress={()=> navigation.navigate("Home")}> */}
                <StyledButton onPress={onPressLogin}>
                    <ButtonText>
                       Login 
                    </ButtonText>
                </StyledButton>

                <Line/>

                <ExtraView>
                <ExtraText> Don't have an account? </ExtraText>
                <TextLink onPress={()=> navigation.navigate("Signup")}>
                    <TextLinkContent>Signup</TextLinkContent>
                </TextLink>
                </ExtraView>

               </StyledFormArea>)}
             </Formik>
        </InnerContainer>
     </StyledContainer>
     </ScrollView>
    //  </KeyboardAvoidWrap>
  );
};

const MyTextInput = ({label, icon, isPassword, hidePassword, setHidePassword, ...props}) => {
return(
    <View>
     <LeftIcon>
        <Octicons name={icon} size={30} color={brand}/>
     </LeftIcon>
     <StyledInputLabel>{label}</StyledInputLabel>
    <StyledTextInput {...props}/>
    {isPassword && (
        <RightIcon onPress={()=> setHidePassword(!hidePassword)}>
         <Ionicons name={hidePassword ? 'eye-off' : 'eye' } size={30} color={darkLight}/>
        </RightIcon>
    )}
    </View>
);
};

export default Login;