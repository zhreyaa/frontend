import RootStack from './navigator/RootStack';
import Login from './screens/Login';
import Chat from './components/Chat';
// import Chat from './components/Chat';
// #124b46
export default function App() {
  console.log("App executed!")
  return (
    <RootStack/>
  );
}
