import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  Image
} from "react-native";
import React, { useState, useEffect, useContext } from "react";
import { TextInput } from "react-native-web";
export default function Notifications()
{
  const [selectedButton, setSelctedButton] = useState("people");
  const [content, setContent] = useState("People Content");
  const handleButtonClick = (buttonName) => {
    setSelctedButton(buttonName);
  };
 
  return (
    <ScrollView style={{backgroundColor:"white" }}>
      <View style={{ padding: 10,marginTop:30 }}>
        <Text style={{ fontSize: 18, fontWeight: "bold", color:"#124b46", alignSelf :"center"}}>NOTIFICATIONS</Text>

        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 10,
            marginTop: 12,
          }}
        >
          {/* <TouchableOpacity
            onPress={() => handleButtonClick("people")}
            style={[
              {
                flex: 1,
                paddingVertical: 10,
                paddingHorizontal: 20,
                backgroundColor: "white",
                borderColor: "#D0D0D0",
                borderRadius: 6,
                borderWidth: 0.7,
              },
              selectedButton === "people" ? { backgroundColor: "#124b46" } : null,
            ]}
          >
            <Text
              style={[
                { textAlign: "center", fontWeight: "bold" },
                selectedButton === "people"
                  ? { color: "white" }
                  : { color: "black" },
              ]}
            >
              People
            </Text>
          </TouchableOpacity> */}

          <TouchableOpacity
            onPress={() => handleButtonClick("all")}
            style={[
              {
                flex: 1,
                paddingVertical: 10,
                paddingHorizontal: 20,
                backgroundColor: "white",
                borderColor: "#D0D0D0",
                borderRadius: 6,
                borderWidth: 0.7,
              },
              selectedButton === "all" ? { backgroundColor: "#124b46" } : null,
            ]}
          >
            <Text
              style={[
                { textAlign: "center", fontWeight: "bold" },
                selectedButton === "all"
                  ? { color: "white" }
                  : { color: "black" },
              ]}
            >
              All
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => handleButtonClick("requests")}
            style={[
              {
                flex: 1,
                paddingVertical: 10,
                paddingHorizontal: 20,
                backgroundColor: "white",
                borderColor: "#D0D0D0",
                borderRadius: 6,
                borderWidth: 0.7,
              },
              selectedButton === "requests"
                ? { backgroundColor: "#124b46" }
                : null,
            ]}
          >
            <Text
              style={[
                { textAlign: "center", fontWeight: "bold" },
                selectedButton === "requests"
                  ? { color: "white" }
                  : { color: "black" },
              ]}
            >
              Requests
            </Text>
          </TouchableOpacity>
        </View>
        <View
        style={{
          marginTop:20,
          flexDirection: "row",
          alignItems: "center",
          gap: 10,
          padding: 20,
          backgroundColor:"#124b46",
          // paddingTop:20
        }}>
        <View>
        <Image
          style={{
            width: 40,
            height: 40,
            borderRadius: 20,
            resizeMode: "contain",
          }}
          source={require("../assets/healofy.png")}
        />

        {/* <Text style={{color:"white"}} >Shreya Chavan</Text> */}
      </View>
      <View style={{ flexDirection: "row", marginLeft: 10 }}>
        <Text style={{color:"white"}}>Doctor has accepted your request to chat!</Text>
      </View>
</View>
      </View>
    </ScrollView>
  );
};


const styles = StyleSheet.create({});