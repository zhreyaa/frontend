import React, {useState} from 'react';
import { StatusBar } from 'expo-status-bar';
import {Octicons, Ionicons, Fontisto} from '@expo/vector-icons';
import {
    StyledContainer,
    InnerContainer,
    PageLogo,
    PageTitle,
    StyledFormArea,
    SubTitle,
    RightIcon,
    LeftIcon,
    ButtonText,
    StyledButton,
    StyledInputLabel,
    StyledTextInput,
    Colors,
    Msgbox,
    Line,
    ExtraText,
    ExtraView,
    TextLink,
    TextLinkContent
} from './../components/styles';

import {Formik} from 'formik';
import KeyboardAvoidWrap from '../components/KeyboardAvoidWrap';
import { Alert, View } from 'react-native';

const {brand, darkLight, primary} = Colors;

const Login = ({navigation}) => {
    
    const [hidePassword, setHidePassword] = useState(true);
    const [email,setEmail] = useState("");
    const [password,setPassword]=useState("");
   
    const onHandleLogin=()=>{
        if(email!=="" && password!==""){
            signInWithEmailAndPassword(auth,email,password)
              .then(()=>navigation.navigate("Home"), console.log("Login sucessful"))
              .catch((err)=>Alert.alert("Login error",err.message));
        }
        
    };

  return (
    <KeyboardAvoidWrap>
     <StyledContainer style={{backgroundColor: "white"}}>
     <StatusBar style='dark'/>
        <InnerContainer style={{backgroundColor:"white"}}>
             <PageLogo
                 resizeMode="cover" source={require('./../assets/healofy.png')} 
                />
             <PageTitle>HEALOFY</PageTitle>
             <SubTitle>Account Login</SubTitle>
            
             <Formik
             initialValues={{email: '', password: ""}}
             onSubmit={(values) =>{
                console.log(values);
                navigation.navigate("Home");
             }}
             >
               {({handleChange, handleBlur, values})=>(
                <StyledFormArea>
               
                <MyTextInput
                    label="Email Address"
                    icon="mail"
                    placeholder="xyz.gmail.com"
                    placeholderTextColor={darkLight}
                    onChangeText={handleChange('email')}
                    onBlur={handleBlur('email')}
                    values={email}
                    keyboardType="email-address"
                    onChange={(text)=>setEmail(text)}
                />

                <MyTextInput
                    label="Password"
                    icon="lock"
                    placeholder="* * * * * *"
                    placeholderTextColor={darkLight}
                    onChangeText={handleChange('password')}
                    onBlur={handleBlur('password')}
                    values={password}
                    secureTextEntry={hidePassword}
                    isPassword={true}
                    hidePassword={hidePassword}
                    setHidePassword={setHidePassword}
                    onChange={(text)=>setPassword(text)}
                />

                <Msgbox>
                    ...
                </Msgbox>

                <StyledButton onPress={onHandleLogin}>
                    <ButtonText>
                       Login 
                    </ButtonText>
                </StyledButton>

                <Line/>

                {/* <StyledButton google={true} onPress={()=> navigation.navigate("Home")}>
                <Fontisto name="google" color={primary} size={25} />
                    <ButtonText google={true}>
                       Sign in with Google
                    </ButtonText>
                </StyledButton> */}

                <ExtraView>
                <ExtraText> Don't have an account? </ExtraText>
                <TextLink onPress={()=> navigation.navigate("Signup")}>
                    <TextLinkContent>Signup</TextLinkContent>
                </TextLink>
                </ExtraView>

               </StyledFormArea>)}
             </Formik>
        </InnerContainer>
     </StyledContainer>
     </KeyboardAvoidWrap>
  );
};

const MyTextInput = ({label, icon, isPassword, hidePassword, setHidePassword, ...props}) => {
return(
    <View>
     <LeftIcon>
        <Octicons name={icon} size={30} color={brand}/>
     </LeftIcon>
     <StyledInputLabel>{label}</StyledInputLabel>
    <StyledTextInput {...props}/>
    {isPassword && (
        <RightIcon onPress={()=> setHidePassword(!hidePassword)}>
         <Ionicons name={hidePassword ? 'eye-off' : 'eye' } size={30} color={darkLight}/>
        </RightIcon>
    )}
    </View>
);
};

export default Login;
