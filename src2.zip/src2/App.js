import RootStack from './navigators/RootStack';

export default function App() {
  console.log("App executed")
  return <RootStack/>;
}

